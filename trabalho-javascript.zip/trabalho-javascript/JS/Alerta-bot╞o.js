function myFunction() {
    var txt;
    if (confirm("Pressione um botão")) {
      txt = "aceitou";
    } else {
      txt = "Cancelou";
    }
    document.getElementById("cont").innerHTML = txt;
  }