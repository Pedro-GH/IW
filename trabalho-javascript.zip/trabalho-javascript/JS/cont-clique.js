var ContVal = 0;

function Click() {
  updateDisplay(++ContVal);
}

function Reset() {
  ContVal = 0;
  updateDisplay(ContVal);
}

function updateDisplay(Val) {
  document.getElementById('Cont').innerHTML = Val;
}