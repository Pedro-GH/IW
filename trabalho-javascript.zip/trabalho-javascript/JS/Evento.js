 function passou()
{
    var pass = document.getElementById("pass")
}

 function onf(x) 
{
    x.style.background = "cyan";
}

function Onc() {
    var x = document.getElementById("mySelect").value;
    document.getElementById("demo").innerHTML = "You selected: " + x;
  }