
       function chama(){
        const elemento1 = document.getElementById("in").value;
        console.log(elemento1); 
       } 
       {
        let list = document.getElementsByTagName("li")
        console.log(list);
       }

       {
        let list = document.getElementsByClassName("border");
        console.log(list);
       }
       
       {
        
        const Qlist = document.querySelector("li");
        console.log(Qlist);

       }
       {
        const nodeList = document.querySelectorAll(".Query");
        console.log(nodeList);

       }
    
      
         
        
     