function greet(name) {
    const outputDiv = document.getElementById('output');
    outputDiv.innerHTML += "<p>" + greet.name + ": Oi, " + name + "!</p>";
}
greet("Gustavo"); 


function square(number) {
    return number * number;
}
const resultSquare = square(5);
const outputDiv = document.getElementById('output');
outputDiv.innerHTML += "<p>" + square.name + ": O quadrado de 5 é: " + resultSquare + "</p>";


const multiply = new Function('x', 'y', 'return x * y');
const product = multiply(3, 4);
outputDiv.innerHTML += "<p>" + multiply.name + ": O produto de 3 e 4 é: " + product + "</p>";


const greetLiteral = function (name) {
    const outputDiv = document.getElementById('output');
    outputDiv.innerHTML += "<p>Função Literal: Olá, " + name + "!</p>";
};
greetLiteral("Wlliam"); 


const greetArrow = (name) => {
    const outputDiv = document.getElementById('output');
    outputDiv.innerHTML += "<p>Função de Flecha: Olá, " + name + "!</p>";
};
greetArrow("Gabriel");